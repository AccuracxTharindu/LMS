<?php include ('header.php'); ?>

        <div class="page-title">
            <div class="title_left">
                <h3>
					<small>Home /</small> <i class= "fa fa-cog fa-spin"></i> Settings
                </h3>
            </div>
        </div>
        <div class="clearfix"></div>
 
        <div class="row">
		
	<?php include ('allowed_qntty.php'); ?>
	
	<?php include ('penalty.php'); ?>
	
	<?php include ('allowed_days.php'); ?>
	
    <div class="clearfix"></div>
		
        </div>

<?php include ('footer.php'); ?>